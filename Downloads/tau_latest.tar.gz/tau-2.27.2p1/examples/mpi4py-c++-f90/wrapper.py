import tau

def OurMain():
    import samarcrun

tau.run('OurMain()')

