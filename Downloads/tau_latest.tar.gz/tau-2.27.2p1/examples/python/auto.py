#!/usr/bin/env python

import tau
from time import sleep

def f2():
    print("Inside f2: sleeping for 2 secs...")
    sleep(2)
def f1():
    print("Inside f1, calling f2...")
    f2()

def OurMain():
    f1()

tau.run('OurMain()')

