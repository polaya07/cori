#include "bar.h"
int foo(int x) {
  bar(4);
  return bar(x-1);
}
  
