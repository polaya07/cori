#ifndef _BAR_H_
#define _BAR_H_
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
extern int bar(int x);

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* _BAR_H_ */

