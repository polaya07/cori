extern int foo(int x);
int main(int argc, char **argv) {
  return foo(32);
}
