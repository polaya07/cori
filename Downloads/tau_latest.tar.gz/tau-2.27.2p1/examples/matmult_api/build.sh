export TAU_MAKEFILE=../../include/Makefile
export TAU_OPTIONS='-optLinkOnly'

tau_f90.sh matmult.ss.f90 -o matmul.ss
