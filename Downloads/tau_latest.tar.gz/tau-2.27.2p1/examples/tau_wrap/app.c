#include <stdio.h>
#include <secret.h>

int main(int argc, char **argv)
{
  foo1(2);
  foo2(4, 1);
  return 0;
}
