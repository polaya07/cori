#ifndef _SECRET_H_
#define _SECRET_H_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int foo1(int a);
void foo2(int b, int c);

#ifdef __cplusplus
}
#endif /* _cplusplus */

#endif /* _SECRET_H_ */
