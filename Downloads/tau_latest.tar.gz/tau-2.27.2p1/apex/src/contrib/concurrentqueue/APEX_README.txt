This implementation was cloned from https://github.com/cameron314/concurrentqueue on August 27, 2015.
The following directories were removed for space considerations:
- benchmarks
- build
- tests
