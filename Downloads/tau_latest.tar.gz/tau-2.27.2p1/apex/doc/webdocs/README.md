To deploy the documentation to github, run this command:

		mkdocs gh-deploy --clean
