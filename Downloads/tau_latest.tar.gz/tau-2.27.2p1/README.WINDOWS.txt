To build TAU for windows use Makefile.win32

The base library and utilities can be build using either Microsoft
Visual C++ 6 or 7 (.NET).  The tau_instrumentor and tau2vtf can only
be built using MSVC++ 7 or higher.

Read the instructions at the top of Makefile.win32 for details on how
to invoke nmake.
